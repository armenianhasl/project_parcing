from __future__ import annotations

import json
from typing import Any, Dict, List
from urllib.parse import urlencode

import certifi
import urllib3

GAMMA_URL = "https://gamma-api.polymarket.com/markets"
HTTP = urllib3.PoolManager(cert_reqs="CERT_REQUIRED", ca_certs=certifi.where())


def _payload_to_markets(payload: Any) -> List[Dict[str, Any]]:
    if isinstance(payload, list):
        return [m for m in payload if isinstance(m, dict)]
    if isinstance(payload, dict):
        for key in ("data", "markets", "results"):
            value = payload.get(key)
            if isinstance(value, list):
                return [m for m in value if isinstance(m, dict)]
    return []


def build_market_lookup(limit: int = 1000, page_size: int = 200) -> Dict[str, dict]:
    """
    Возвращает словарь:
    condition_id (hex) -> {
        "question": str,
        "slug": str,
        "end_date": str,
        "active": bool
    }
    """
    lookup: Dict[str, dict] = {}
    offset = 0

    while len(lookup) < limit:
        params = {
            "active": "true",
            "closed": "false",
            "limit": min(page_size, max(1, limit - len(lookup))),
            "offset": offset,
        }
        url = f"{GAMMA_URL}?{urlencode(params)}"
        response = HTTP.request(
            "GET",
            url,
            headers={"Accept": "application/json"},
            timeout=20.0,
            retries=False,
        )
        if response.status >= 300:
            raise RuntimeError(
                f"Gamma API error {response.status}: {response.data.decode('utf-8', errors='replace')}"
            )

        payload = json.loads(response.data.decode("utf-8"))
        markets = _payload_to_markets(payload)
        if not markets:
            break

        for market in markets:
            condition_id = str(
                market.get("conditionId")
                or market.get("condition_id")
                or market.get("market")
                or market.get("id")
                or ""
            )
            if not condition_id:
                continue

            lookup[condition_id] = {
                "question": market.get("question"),
                "slug": market.get("slug"),
                "end_date": market.get("endDate") or market.get("end_date"),
                "active": market.get("active"),
            }

            if len(lookup) >= limit:
                break

        if len(markets) < params["limit"]:
            break
        offset += params["limit"]

    return lookup
