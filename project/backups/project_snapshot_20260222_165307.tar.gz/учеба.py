N = int(input())
i = int(input())

while N < 10:
    i+=i
    N+=1
    print(N)

    
    