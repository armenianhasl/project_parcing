import os
import sys
import contextlib
import json
from datetime import datetime
from typing import Any, Dict, List, Optional, Sequence, Tuple
from dotenv import load_dotenv

# Load secrets/config from files if present (preferred), then from environment
# Put secrets into password.env (recommended) or .env
load_dotenv("password.env")
load_dotenv()

import clickhouse_connect
# --------------------
# Config (env)
# --------------------
LIMIT = int(os.getenv("LIMIT", "20"))
TABLE = os.getenv("TABLE", "polyk.pm_price_change")
MARKET = os.getenv("MARKET", "").strip()
MINUTES = int(os.getenv("MINUTES", "0"))  # 0 = disabled
SHOW_RAW = os.getenv("SHOW_RAW", "false").lower() in ("1", "true", "yes")

# Output to file (optional)
OUT_FILE = os.getenv("OUT_FILE", "").strip()  # e.g. out.txt
OUT_MODE = os.getenv("OUT_MODE", "w").strip().lower()  # w|a

START_TIME = os.getenv("START_TIME", "").strip()
END_TIME = os.getenv("END_TIME", "").strip()

# Output order for events/levels
# asc  -> oldest first (event_time increasing)
# desc -> newest first
ORDER = os.getenv("ORDER", "asc").strip().lower()
ORDER_DIR = "ASC" if ORDER in ("asc", "up", "oldest") else "DESC"
OUTPUT_TZ = os.getenv("OUTPUT_TZ", "Europe/Moscow").strip().replace("'", "") or "Europe/Moscow"

CH_HOST = os.getenv("CLICKHOUSE_HOST", "89.169.153.71")
CH_PORT = int(os.getenv("CLICKHOUSE_PORT", "8123"))
CH_USER = os.getenv("CLICKHOUSE_USER", "remote_ingest")
CH_PASS = os.getenv("CLICKHOUSE_PASSWORD", "").strip()
CH_DB = os.getenv("CLICKHOUSE_DB", "polyk")

if not CH_PASS:
    raise RuntimeError(
        "CLICKHOUSE_PASSWORD is empty.\n"
        "Set it in password.env (CLICKHOUSE_PASSWORD=...) or export CLICKHOUSE_PASSWORD=..."
    )

c = clickhouse_connect.get_client(
    host=CH_HOST,
    port=CH_PORT,
    username=CH_USER,
    password=CH_PASS,
    database=CH_DB,
    secure=False,
    apply_server_timezone=False,
)


def _fmt(x: Any) -> str:
    if x is None:
        return ""
    if isinstance(x, datetime):
        return x.isoformat(sep=" ")
    return str(x)


def _print_table(
    headers: List[str],
    rows: List[List[Any]],
    *,
    max_width: int = 80,
    max_widths: Optional[Dict[str, int]] = None,
    right_align: Optional[set[str]] = None,
) -> None:
    widths = [len(h) for h in headers]
    max_widths = max_widths or {}
    right_align = right_align or set()

    for r in rows:
        for i, v in enumerate(r):
            cap = max_widths.get(headers[i], max_width)
            widths[i] = min(max(widths[i], len(_fmt(v))), cap)

    def crop(s: str, w: int) -> str:
        if len(s) <= w:
            return s
        if w <= 1:
            return s[:w]
        return s[: w - 1] + "…"

    line = "+" + "+".join("-" * (w + 2) for w in widths) + "+"
    print(line)
    print(
        "| "
        + " | ".join(crop(h, widths[i]).ljust(widths[i]) for i, h in enumerate(headers))
        + " |"
    )
    print(line)

    for r in rows:
        cells: List[str] = []
        for i, v in enumerate(r):
            s = crop(_fmt(v), widths[i])
            if headers[i] in right_align:
                cells.append(s.rjust(widths[i]))
            else:
                cells.append(s.ljust(widths[i]))
        print("| " + " | ".join(cells) + " |")

    print(line)


def _parse_json_maybe(s: Any) -> Any:
    if not isinstance(s, str):
        return None
    s = s.strip()
    if not s:
        return None
    try:
        return json.loads(s)
    except Exception:
        return None


def _where_market(alias: str = "") -> str:
    if not MARKET:
        return ""
    prefix = f"{alias}." if alias else ""
    return f"{prefix}market = '{MARKET}'"


def _where_last_minutes(ts_col: str) -> str:
    if MINUTES <= 0:
        return ""
    # ts_col is milliseconds
    return f"{ts_col} >= (toUnixTimestamp(now()) - {MINUTES} * 60) * 1000"


def _where_between(ts_col: str) -> str:
    if not START_TIME or not END_TIME:
        return ""
    return (
        f"{ts_col} >= toUnixTimestamp(toDateTime('{START_TIME}')) * 1000 "
        f"AND {ts_col} < toUnixTimestamp(toDateTime('{END_TIME}')) * 1000"
    )


def _join_where(clauses: Sequence[str]) -> str:
    clauses = [c for c in clauses if c]
    if not clauses:
        return ""
    return "WHERE " + "\n  AND ".join(clauses)


def _event_time_expr(ts_col: str, alias: str = "event_time_msk") -> str:
    return (
        f"toTimeZone(toDateTime64(({ts_col}) / 1000.0, 3, 'UTC'), "
        f"'{OUTPUT_TZ}') AS {alias}"
    )


def _maybe_redirect_stdout():
    """If OUT_FILE is set, redirect all prints to that file (and keep console quiet)."""
    if not OUT_FILE:
        return contextlib.nullcontext()
    mode = "a" if OUT_MODE == "a" else "w"
    # line-buffered for readability
    f = open(OUT_FILE, mode, encoding="utf-8")
    return contextlib.redirect_stdout(f)


# --------------------
# Mode detection
# --------------------
IS_LEVELS = "_levels" in TABLE

def _split_table(full: str) -> Tuple[str, str]:
    s = full.strip()
    if "." in s:
        db, tbl = s.split(".", 1)
        return db, tbl
    return CH_DB, s


def _get_columns(full: str) -> set[str]:
    db, tbl = _split_table(full)
    q = """
SELECT name
FROM system.columns
WHERE database = %(db)s AND table = %(tbl)s
"""
    rows = c.query(q, parameters={"db": db, "tbl": tbl}).result_rows
    return {r[0] for r in rows}

# --------------------
# Query + Output
# --------------------
with _maybe_redirect_stdout():
    if IS_LEVELS:
        # Heuristic: handle both price_change_levels and orderbook_levels
        cols = _get_columns(TABLE)
        is_price_levels = "price_change" in TABLE or ("best_bid" in cols and "best_ask" in cols)

        if is_price_levels:
            # Supported shapes:
            # - ingest_time, market, event_ts_ms, asset_id, side,    price, size, hash, best_bid, best_ask
            # - ingest_time, market, event_ts_ms, asset_id, outcome, price, size, hash, best_bid, best_ask
            side_expr = "side" if "side" in cols else ("outcome" if "outcome" in cols else "''")
            side_header = "side" if "side" in cols else "outcome"
            time_clause = _where_between("event_ts_ms") or _where_last_minutes("event_ts_ms")
            where_sql = _join_where([
                _where_market(""),
                time_clause,
            ])

            q = f"""
SELECT
    ingest_time,
    market,
    event_ts_ms,
    {_event_time_expr("event_ts_ms")},
    asset_id,
    {side_expr} AS side_or_outcome,
    price,
    size,
    best_bid,
    best_ask,
    hash
FROM {TABLE}
{where_sql}
ORDER BY event_ts_ms {ORDER_DIR}
LIMIT {LIMIT}
"""
            rows = c.query(q).result_rows

            print("\n" + "=" * 110)
            print(f"TABLE: {TABLE}  (levels)  LIMIT={LIMIT}  MINUTES={MINUTES or 'off'}  ORDER={ORDER_DIR}")
            if MARKET:
                print(f"MARKET={MARKET}")
            print("=" * 110)

            headers = [
                "ingest_time",
                "market",
                "event_ts_ms",
                "event_time_msk",
                "asset_id",
                side_header,
                "price",
                "size",
                "best_bid",
                "best_ask",
                "hash",
            ]
            _print_table(
                headers,
                [list(r) for r in rows],
                max_width=80,
                max_widths={"market": 18, "asset_id": 24, "hash": 16},
                right_align={"event_ts_ms", "price", "size", "best_bid", "best_ask"},
            )

        else:
            # Orderbook levels (best effort):
            # ingest_time, market, event_ts_ms, asset_id, [side|outcome], price, size
            side_expr = "side" if "side" in cols else ("outcome" if "outcome" in cols else "''")
            side_header = "side" if "side" in cols else "outcome"
            time_clause = _where_between("event_ts_ms") or _where_last_minutes("event_ts_ms")
            where_sql = _join_where([
                _where_market(""),
                time_clause,
            ])

            q = f"""
SELECT
    ingest_time,
    market,
    event_ts_ms,
    {_event_time_expr("event_ts_ms")},
    asset_id,
    {side_expr} AS side_or_outcome,
    price,
    size
FROM {TABLE}
{where_sql}
ORDER BY event_ts_ms {ORDER_DIR}
LIMIT {LIMIT}
"""
            rows = c.query(q).result_rows

            print("\n" + "=" * 110)
            print(f"TABLE: {TABLE}  (levels)  LIMIT={LIMIT}  MINUTES={MINUTES or 'off'}  ORDER={ORDER_DIR}")
            if MARKET:
                print(f"MARKET={MARKET}")
            print("=" * 110)

            headers = [
                "ingest_time",
                "market",
                "event_ts_ms",
                "event_time_msk",
                "asset_id",
                side_header,
                "price",
                "size",
            ]
            _print_table(
                headers,
                [list(r) for r in rows],
                max_width=80,
                max_widths={"market": 18, "asset_id": 24},
                right_align={"event_ts_ms", "price", "size"},
            )

    else:
        # Event table mode (pm_price_change or pm_orderbook-like)
        # Default expected columns (your earlier project):
        # ingest_time, event_type, market, timestamp_ms, price_changes, raw
        cols = _get_columns(TABLE)
        ts_col = "event_ts_ms" if "event_ts_ms" in cols else "timestamp_ms"

        # Pick columns that may vary between evt schemas
        pc_col = None
        for cand in ("price_changes", "price_changes_json", "price_changes_raw", "price_changes_str"):
            if cand in cols:
                pc_col = cand
                break

        raw_col = None
        for cand in ("raw", "raw_json", "payload", "payload_json"):
            if cand in cols:
                raw_col = cand
                break

        time_clause = _where_between(ts_col) or _where_last_minutes(ts_col)
        where_sql = _join_where([
            _where_market(""),
            time_clause,
        ])

        q = f"""
SELECT
  ingest_time,
  {"event_type" if "event_type" in cols else "''"} AS event_type,
  market,
  {ts_col} AS ts_ms,
  {_event_time_expr(ts_col)},
  {pc_col if pc_col else "NULL"} AS price_changes_s,
  {raw_col if raw_col else "NULL"} AS raw_s
FROM {TABLE}
{where_sql}
ORDER BY {ts_col} {ORDER_DIR}
LIMIT {LIMIT}
"""

        rows = c.query(q).result_rows

        for idx, (ingest_time, event_type, market, ts_ms, event_time_msk, price_changes_s, raw_s) in enumerate(rows, 1):
            print("\n" + "=" * 110)
            print(f"EVENT {idx}/{len(rows)}")
            print("=" * 110)

            _print_table(
                ["event_time_msk", "event_ts_ms", "ingest_time", "event_type", "market"],
                [[
                    event_time_msk,
                    ts_ms,
                    ingest_time,
                    event_type,
                    market
                ]],
                max_width=120,
                max_widths={"market": 60},
                right_align=set(),
            )

            # price_changes may come from ClickHouse as:
            # - String containing JSON
            # - native Array(...) decoded as Python list (of dicts OR tuples)
            # - NULL (None)
            # - sometimes a dict wrapper
            pcs = None

            def _unwrap_price_changes(obj: Any) -> Any:
                if isinstance(obj, dict):
                    return obj.get("price_changes") or obj.get("data")
                return obj

            if isinstance(price_changes_s, list):
                pcs = price_changes_s
            elif isinstance(price_changes_s, dict):
                pcs = _unwrap_price_changes(price_changes_s)
            elif isinstance(price_changes_s, str):
                pcs = _unwrap_price_changes(_parse_json_maybe(price_changes_s))

            # If still nothing, try to extract from raw/payload JSON
            if pcs is None and raw_s is not None:
                raw_obj = raw_s
                if isinstance(raw_s, str):
                    raw_obj = _parse_json_maybe(raw_s)
                pcs = _unwrap_price_changes(raw_obj) if raw_obj is not None else None

            # Normalize Array(Tuple(...)) -> list[dict]
            if isinstance(pcs, list) and pcs:
                if isinstance(pcs[0], tuple):
                    # common tuple layout in our schema: (asset_id, side, price, size, best_bid, best_ask, hash)
                    keys = ("asset_id", "side", "price", "size", "best_bid", "best_ask", "hash")
                    new_pcs: List[Dict[str, Any]] = []
                    for t in pcs:
                        if not isinstance(t, tuple):
                            continue
                        d: Dict[str, Any] = {}
                        for i, k in enumerate(keys):
                            if i < len(t):
                                d[k] = t[i]
                        new_pcs.append(d)
                    pcs = new_pcs
                elif isinstance(pcs[0], list):
                    # list-of-lists, treat similarly to tuples
                    keys = ("asset_id", "side", "price", "size", "best_bid", "best_ask", "hash")
                    new_pcs = []
                    for t in pcs:
                        if not isinstance(t, list):
                            continue
                        d: Dict[str, Any] = {}
                        for i, k in enumerate(keys):
                            if i < len(t):
                                d[k] = t[i]
                        new_pcs.append(d)
                    pcs = new_pcs

            if isinstance(pcs, list) and pcs:
                # Stable ordering inside price_changes[]: BUY first, then SELL; then asset_id; then numeric price
                def _side_rank(s: Any) -> int:
                    ss = str(s or "").upper()
                    if ss == "BUY":
                        return 0
                    if ss == "SELL":
                        return 1
                    return 9

                def _to_float(x: Any) -> float:
                    try:
                        return float(x)
                    except Exception:
                        return float("nan")

                pcs_sorted = []
                for pc in pcs:
                    if not isinstance(pc, dict):
                        continue
                    pcs_sorted.append(pc)

                pcs_sorted.sort(
                    key=lambda d: (
                        _side_rank(d.get("side")),
                        str(d.get("asset_id", "")),
                        _to_float(d.get("price")),
                    )
                )

                lvl_rows: List[List[Any]] = []
                for pc in pcs_sorted:
                    lvl_rows.append(
                        [
                            pc.get("asset_id", ""),
                            str(pc.get("side", "") or "").upper(),
                            pc.get("price", ""),
                            pc.get("size", ""),
                            pc.get("best_bid", ""),
                            pc.get("best_ask", ""),
                            pc.get("hash", ""),
                        ]
                    )
                if lvl_rows:
                    print("\nPRICE_CHANGES (rows inside price_changes[]):")
                    _print_table(
                        ["asset_id", "side", "price", "size", "best_bid", "best_ask", "hash"],
                        lvl_rows,
                        max_width=80,
                        max_widths={"asset_id": 24, "hash": 16},
                        right_align={"price", "size", "best_bid", "best_ask"},
                    )
                else:
                    print("\nPRICE_CHANGES: (parsed, but empty or not dicts)")
            else:
                print("\nPRICE_CHANGES: (not an array / empty)")
                print("DEBUG price_changes_s type:", type(price_changes_s), "value:", str(price_changes_s)[:200])
                print("DEBUG raw_s type:", type(raw_s), "value:", str(raw_s)[:200])

            if SHOW_RAW:
                raw = _parse_json_maybe(raw_s)
                print("\nRAW JSON:")
                if raw is not None:
                    print(json.dumps(raw, ensure_ascii=False, indent=2)[:8000])
                else:
                    print(str(raw_s)[:8000])

    print("\nDone.")

if OUT_FILE:
    sys.__stdout__.write(f"\nSaved output to: {OUT_FILE}\n")
