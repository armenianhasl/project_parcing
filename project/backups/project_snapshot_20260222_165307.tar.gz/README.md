# Polymarket Crypto Ingest

Ingest pipeline for Polymarket crypto markets:
- discovers markets from Gamma API,
- subscribes to Polymarket Market WebSocket by `asset_id`,
- computes top-of-book from `book` snapshots,
- writes normalized rows to ClickHouse.

## Main scripts

- `ws_ingest.py`: production ingest loop (Gamma discovery + WS + ClickHouse insert), including UP-enriched events table for CH-only modeling.
- `check_data.py`: query helper for ClickHouse tables.
- `market_lookup.py`: build market metadata lookup.
- `main.py`: lightweight WS smoke test for selected asset ids.
- `poly_markets.py`: optional static market/asset mapping.
- `mispricing_realtime.py`: CH-only realtime mispricing (UP trades only) from enriched ClickHouse events (no RTDS dependency).

## Quick start

1. Create env files from template:
   - copy `.env.example` to `.env`
   - create `password.env` with `CLICKHOUSE_PASSWORD=...`
2. Install dependencies:
   - `pip install websockets urllib3 certifi python-dotenv clickhouse-connect`
3. Run ingest:
   - `python ws_ingest.py`
4. Run mispricing stream:
   - `python mispricing_realtime.py`

## Key env vars

- Discovery/filter:
  - `POLY_TAG_ID` (default `21`, crypto tag)
  - `POLY_ACTIVE` (default `true`)
  - `POLY_CLOSED` (default `false`)
  - `POLY_LIMIT` (default `200`)
  - `POLY_REFRESH_SEC` (default `60`)
  - `POLY_SYMBOLS` (example: `BTC,ETH,XRP`)
  - `POLY_TIMEFRAMES` (example: `15m,1h,4h`)
- WS:
  - `POLY_WS_URL`
  - `POLY_WS_ORIGIN`
- ClickHouse:
  - `CLICKHOUSE_HOST`
  - `CLICKHOUSE_PORT`
  - `CLICKHOUSE_USER`
  - `CLICKHOUSE_PASSWORD` (recommended in `password.env`)
  - `CLICKHOUSE_DB`
- Ingest tuning:
  - `FLUSH_EVERY_N`
  - `FLUSH_EVERY_SEC`
  - `DEBUG_RAW`
  - `DEBUG_FILTERED_MARKETS`
  - `TOB_SKIP_UNCHANGED` (optional dedup of unchanged top-of-book rows)
  - `WRITE_UP_ENRICHED` (default `true`)
  - `UP_ENRICHED_TABLE` (default `pm_up_enriched_events`)
- Mispricing:
  - `POLY_WHITELIST_MARKET_IDS` (comma-separated market ids or condition ids; can be empty)
  - `AUTO_WHITELIST_ENABLED` (if true and whitelist is empty, take recent UP markets from ClickHouse)
  - `AUTO_WHITELIST_LIMIT` (how many markets to pull into auto-whitelist)
  - `AUTO_WHITELIST_RECENT_SEC` (default `21600`, only markets with recent `event_ts_ms` are included)
  - `POLY_RTDS_URL` (default `wss://ws-live-data.polymarket.com`)
  - `POLY_RTDS_RECONNECT_SEC` (default `2`)
  - `MARKET_META_REFRESH_SEC` (default `60`)
  - `PRICE_STALE_SEC` (default `5`)
  - `PRICE_HARD_EXPIRE_SEC` (default `900`, keep last known RTDS price this long)
  - `GAMMA_HTTP_TIMEOUT_SEC` (default `15`)
  - `GAMMA_MAX_PAGES` (default `20`)
  - `GAMMA_RELAXED_MAX_PAGES` (default `40`)
  - `GAMMA_CONDITION_CHUNK` (default `50`, batch size for `condition_ids` lookup)
  - `MISPRICING_TOP_N`
  - `MISPRICING_EVERY_SEC`
  - `MISPRICING_TABLE`
  - `MISPRICING_EVENTS_TABLE`
  - `MISPRICING_SOURCE_TABLE` (default `pm_up_enriched_events`)
  - `MISPRICING_EVENT_BATCH`
  - `MISPRICING_BOOTSTRAP_SEC`
  - `SIGMA_WINDOW`
  - `SIGMA_MIN_SAMPLES`
  - `RISK_FREE_RATE`

## Notes

- `check_data.py` supports both legacy `side` and newer `outcome` schemas in `*_levels` tables.
- `main.py` no longer stores secrets and uses correct WS subscribe payload:
  - `{"assets_ids": [...], "type": "market"}`
- `ws_ingest.py` writes enriched UP events into `polyk.pm_up_enriched_events` with:
  - `best_bid_price`, `best_ask_price`,
  - parsed `current_price` (underlying spot from Polymarket metadata),
  - parsed `strike_price`,
  - `end_ts_ms`, `symbol`, `timeframe`.
- `mispricing_realtime.py` reads only `polyk.pm_up_enriched_events`, computes rolling sigma from `current_price`, then computes binary Black-Scholes `model_prob_up` and writes divergence to `polyk.pm_mispricing_events`.
- If `POLY_WHITELIST_MARKET_IDS` is empty, script auto-builds whitelist from `pm_top_of_book` (`outcome='UP'`). If table is empty, it temporarily falls back to all discovered crypto markets.
