import os
from typing import Dict, List, Tuple

# poly_markets.py
# Single source of truth for markets and outcomes

# market_id -> {"UP": asset_id, "DOWN": asset_id}
MARKETS: Dict[str, Dict[str, str]] = {
    "0x181c1de9200cf5ea1db41681c891e1268cbcbe85a35a75a82cb65f7606b7fbef": {
        "UP": "24718622518880553545884448796664676452835457189245084861081709575258606189115",
        "DOWN": "33753788871972079734006180104472624459158175992518629714941283739536197582650",
    },
}

def _parse_selected_market_ids() -> List[str]:
    selected = (
        os.getenv("POLY_MARKET_IDS", "").strip()
        or os.getenv("POLY_MARKET_ID", "").strip()
    )
    if selected:
        return [x.strip() for x in selected.split(",") if x.strip()]
    return list(MARKETS.keys())


def _build_maps(selected_market_ids: List[str]) -> Tuple[Dict[str, str], Dict[str, str]]:
    outcome_map: Dict[str, str] = {}
    asset_to_market: Dict[str, str] = {}

    for market_id in selected_market_ids:
        by_outcome = MARKETS[market_id]
        for outcome, asset_id in by_outcome.items():
            if asset_id in outcome_map and outcome_map[asset_id] != outcome:
                raise RuntimeError(
                    f"Asset id {asset_id} is mapped to multiple outcomes: "
                    f"{outcome_map[asset_id]} and {outcome}"
                )
            outcome_map[asset_id] = outcome
            asset_to_market[asset_id] = market_id

    return outcome_map, asset_to_market


SELECTED_MARKET_IDS: List[str] = _parse_selected_market_ids()

# validate
missing = [m for m in SELECTED_MARKET_IDS if m not in MARKETS]
if missing:
    raise RuntimeError(f"Unknown market_id(s): {missing}")

OUTCOME_MAP, ASSET_TO_MARKET = _build_maps(SELECTED_MARKET_IDS)

# assets to subscribe
ASSET_IDS: List[str] = list(OUTCOME_MAP.keys())


def outcome_from_asset_id(asset_id: str) -> str:
    return OUTCOME_MAP.get(str(asset_id), "UNKNOWN")
