from __future__ import annotations

import asyncio
import math
import os
import statistics
from collections import deque
from contextlib import suppress
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from typing import Any, Deque, Dict, List, Optional, Set, Tuple

import clickhouse_connect
from dotenv import load_dotenv


BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, "password.env"), override=True)
load_dotenv(os.path.join(BASE_DIR, ".env"), override=True)

MISPRICING_EVENTS_TABLE = os.getenv("MISPRICING_EVENTS_TABLE", "pm_mispricing_events")
MISPRICING_SOURCE_TABLE = os.getenv(
    "MISPRICING_SOURCE_TABLE",
    os.getenv("UP_ENRICHED_TABLE", "pm_up_enriched_events"),
)
MISPRICING_EVERY_SEC = float(os.getenv("MISPRICING_EVERY_SEC", "1"))
MISPRICING_EVENT_BATCH = int(os.getenv("MISPRICING_EVENT_BATCH", "5000"))
MISPRICING_BOOTSTRAP_SEC = int(os.getenv("MISPRICING_BOOTSTRAP_SEC", "3600"))

SIGMA_WINDOW = int(os.getenv("SIGMA_WINDOW", "300"))
SIGMA_MIN_SAMPLES = int(os.getenv("SIGMA_MIN_SAMPLES", "30"))
RISK_FREE_RATE = float(os.getenv("RISK_FREE_RATE", "0"))

CH_HOST = os.getenv("CLICKHOUSE_HOST", "89.169.153.71")
CH_PORT = int(os.getenv("CLICKHOUSE_PORT", "8123"))
CH_USER = os.getenv("CLICKHOUSE_USER", "remote_ingest")
CH_PASS = os.getenv("CLICKHOUSE_PASSWORD", "")
CH_DB = os.getenv("CLICKHOUSE_DB", "polyk")

if not CH_PASS:
    raise RuntimeError("CLICKHOUSE_PASSWORD is empty. Set it in password.env or .env")


@dataclass
class UpTradeEvent:
    ingest_time: datetime
    market: str
    gamma_market_id: str
    event_ts_ms: int
    trade_hash: str
    best_bid_price: float
    best_ask_price: float
    current_price: float
    strike_price: float
    symbol: str
    timeframe: str
    end_ts_ms: int


def to_float(value: Any) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value)
    if isinstance(value, str):
        s = value.replace(",", "").strip()
        if not s:
            return None
        try:
            return float(s)
        except Exception:
            return None
    return None


def sql_escape(value: str) -> str:
    return value.replace("\\", "\\\\").replace("'", "\\'")


def sql_quote(value: str) -> str:
    return f"'{sql_escape(value)}'"


def norm_cdf(x: float) -> float:
    return 0.5 * (1.0 + math.erf(x / math.sqrt(2.0)))


def binary_bs_prob_up(spot: float, strike: float, t_years: float, sigma: float, r: float = 0.0) -> float:
    if spot <= 0 or strike <= 0:
        return 0.0
    if t_years <= 0:
        return 1.0 if spot > strike else 0.0
    if sigma <= 0:
        return 1.0 if spot > strike else 0.0

    denom = sigma * math.sqrt(t_years)
    if denom <= 0:
        return 1.0 if spot > strike else 0.0

    d2 = (math.log(spot / strike) + (r - 0.5 * sigma * sigma) * t_years) / denom
    p = norm_cdf(d2)
    return max(0.0, min(1.0, p))


def _table_has_column(client: clickhouse_connect.driver.Client, table: str, column: str) -> bool:
    try:
        rows = client.query(f"DESCRIBE TABLE {CH_DB}.{table}").result_rows
    except Exception:
        return False
    for row in rows:
        if row and str(row[0]) == column:
            return True
    return False


def ensure_events_output_table(client: clickhouse_connect.driver.Client) -> None:
    q = f"""
CREATE TABLE IF NOT EXISTS {CH_DB}.{MISPRICING_EVENTS_TABLE}
(
  ingest_time DateTime,
  market String,
  gamma_market_id String,
  event_ts_ms UInt64,
  event_time_msk DateTime MATERIALIZED toTimeZone(toDateTime(event_ts_ms / 1000), 'Europe/Moscow'),
  trade_hash String,
  symbol String,
  timeframe String,
  current_price Float64,
  strike_price Float64,
  t_years Float64,
  sigma Float64,
  model_prob_up Float64,
  edge_ask Float64,
  abs_edge Float64,
  best_bid_price Float64,
  best_ask_price Float64
)
ENGINE = MergeTree
ORDER BY (event_ts_ms, market, trade_hash)
"""
    client.command(q)

    # Migration from legacy schema names.
    with suppress(Exception):
        if _table_has_column(client, MISPRICING_EVENTS_TABLE, "trade_price_up"):
            client.command(f"ALTER TABLE {CH_DB}.{MISPRICING_EVENTS_TABLE} DROP COLUMN trade_price_up")
    with suppress(Exception):
        if _table_has_column(client, MISPRICING_EVENTS_TABLE, "edge_trade"):
            client.command(f"ALTER TABLE {CH_DB}.{MISPRICING_EVENTS_TABLE} DROP COLUMN edge_trade")
    with suppress(Exception):
        if not _table_has_column(client, MISPRICING_EVENTS_TABLE, "edge_ask"):
            client.command(
                f"ALTER TABLE {CH_DB}.{MISPRICING_EVENTS_TABLE} "
                "ADD COLUMN edge_ask Float64 AFTER model_prob_up"
            )


def ensure_source_table(client: clickhouse_connect.driver.Client) -> None:
    q = f"""
CREATE TABLE IF NOT EXISTS {CH_DB}.{MISPRICING_SOURCE_TABLE}
(
  ingest_time DateTime,
  market String,
  gamma_market_id String,
  event_ts_ms UInt64,
  event_time_msk DateTime MATERIALIZED toTimeZone(toDateTime(event_ts_ms / 1000), 'Europe/Moscow'),
  asset_id String,
  outcome String,
  trade_size_up Float64,
  trade_hash String,
  best_bid_price Float64,
  best_ask_price Float64,
  current_price Float64,
  strike_price Float64,
  symbol String,
  timeframe String,
  end_ts_ms UInt64
)
ENGINE = MergeTree
ORDER BY (event_ts_ms, market, trade_hash)
"""
    client.command(q)

    with suppress(Exception):
        if _table_has_column(client, MISPRICING_SOURCE_TABLE, "trade_price_up"):
            client.command(f"ALTER TABLE {CH_DB}.{MISPRICING_SOURCE_TABLE} DROP COLUMN trade_price_up")


def fetch_recent_up_trade_events(
    client: clickhouse_connect.driver.Client,
    min_ingest_time: datetime,
    limit: int,
) -> List[UpTradeEvent]:
    safe_limit = max(1, int(limit))
    q = f"""
SELECT
  ingest_time,
  market,
  gamma_market_id,
  event_ts_ms,
  trade_hash,
  best_bid_price,
  best_ask_price,
  current_price,
  strike_price,
  symbol,
  timeframe,
  end_ts_ms
FROM {CH_DB}.{MISPRICING_SOURCE_TABLE}
WHERE ingest_time >= toDateTime({sql_quote(min_ingest_time.strftime('%Y-%m-%d %H:%M:%S'))})
ORDER BY ingest_time ASC, event_ts_ms ASC
LIMIT {safe_limit}
"""
    rows = client.query(q).result_rows
    out: List[UpTradeEvent] = []

    for (
        ingest_time,
        market,
        gamma_market_id,
        event_ts_ms,
        trade_hash,
        best_bid,
        best_ask,
        current_price,
        strike_price,
        symbol,
        timeframe,
        end_ts_ms,
    ) in rows:
        ing = ingest_time.replace(tzinfo=None) if isinstance(ingest_time, datetime) else datetime.now(timezone.utc).replace(tzinfo=None)
        out.append(
            UpTradeEvent(
                ingest_time=ing,
                market=str(market),
                gamma_market_id=str(gamma_market_id or ""),
                event_ts_ms=int(event_ts_ms),
                trade_hash=str(trade_hash or ""),
                best_bid_price=float(to_float(best_bid) or 0.0),
                best_ask_price=float(to_float(best_ask) or 0.0),
                current_price=float(to_float(current_price) or 0.0),
                strike_price=float(to_float(strike_price) or 0.0),
                symbol=str(symbol or ""),
                timeframe=str(timeframe or ""),
                end_ts_ms=int(to_float(end_ts_ms) or 0),
            )
        )
    return out


def insert_mispricing_event_rows(client: clickhouse_connect.driver.Client, rows: List[Tuple]) -> None:
    if not rows:
        return

    values_sql: List[str] = []
    for row in rows:
        ingest_time = row[0].strftime("%Y-%m-%d %H:%M:%S")
        values_sql.append(
            "("
            + ", ".join(
                [
                    sql_quote(ingest_time),
                    sql_quote(str(row[1])),
                    sql_quote(str(row[2])),
                    str(int(row[3])),
                    sql_quote(str(row[4])),
                    sql_quote(str(row[5])),
                    sql_quote(str(row[6])),
                    f"{float(row[7]):.12g}",
                    f"{float(row[8]):.12g}",
                    f"{float(row[9]):.12g}",
                    f"{float(row[10]):.12g}",
                    f"{float(row[11]):.12g}",
                    f"{float(row[12]):.12g}",
                    f"{float(row[13]):.12g}",
                    f"{float(row[14]):.12g}",
                    f"{float(row[15]):.12g}",
                ]
            )
            + ")"
        )

    q = f"""
INSERT INTO {CH_DB}.{MISPRICING_EVENTS_TABLE}
(ingest_time, market, gamma_market_id, event_ts_ms, trade_hash, symbol, timeframe, current_price, strike_price, t_years, sigma, model_prob_up, edge_ask, abs_edge, best_bid_price, best_ask_price)
VALUES
{", ".join(values_sql)}
"""
    client.command(q)


class RollingSigma:
    def __init__(self, window: int):
        self.window = max(2, window)
        self.prev_price: Dict[str, float] = {}
        self.returns: Dict[str, Deque[float]] = {}

    def update(self, key: str, price: float) -> None:
        if price <= 0:
            return
        prev = self.prev_price.get(key)
        self.prev_price[key] = price
        if prev is None or prev <= 0:
            return
        ret = math.log(price / prev)
        d = self.returns.setdefault(key, deque(maxlen=self.window))
        d.append(ret)

    def sigma_annualized(self, key: str, step_seconds: float, min_samples: int) -> Optional[float]:
        d = self.returns.get(key)
        if not d or len(d) < min_samples:
            return None
        stdev = statistics.pstdev(d)
        if stdev <= 0:
            return 0.0
        sec_per_year = 365.0 * 24.0 * 3600.0
        return float(stdev * math.sqrt(sec_per_year / max(step_seconds, 1e-9)))


def build_event_rows_for_insert(
    events: List[UpTradeEvent],
    sigma_state: RollingSigma,
    now_utc: datetime,
    inferred_strikes: Dict[str, float],
) -> List[Tuple]:
    rows: List[Tuple] = []
    fallback_min_samples = max(2, min(SIGMA_MIN_SAMPLES, 8))

    for event in events:
        current_price = float(event.current_price)
        if current_price <= 0:
            continue

        sigma_key = event.symbol.strip().upper() if event.symbol else event.market
        sigma_state.update(sigma_key, current_price)
        sigma = sigma_state.sigma_annualized(sigma_key, MISPRICING_EVERY_SEC, SIGMA_MIN_SAMPLES)
        if sigma is None:
            sigma = sigma_state.sigma_annualized(sigma_key, MISPRICING_EVERY_SEC, fallback_min_samples)
        if sigma is None:
            continue

        strike = float(event.strike_price)
        if strike <= 0:
            strike = inferred_strikes.get(event.market) or 0.0
            if strike <= 0:
                strike = current_price
                inferred_strikes[event.market] = strike

        event_dt_utc = datetime.fromtimestamp(event.event_ts_ms / 1000.0, tz=timezone.utc)
        end_dt_utc = datetime.fromtimestamp(event.end_ts_ms / 1000.0, tz=timezone.utc) if event.end_ts_ms > 0 else event_dt_utc
        t_years = max((end_dt_utc - event_dt_utc).total_seconds(), 0.0) / (365.0 * 24.0 * 3600.0)

        model_prob = binary_bs_prob_up(
            spot=current_price,
            strike=strike,
            t_years=t_years,
            sigma=sigma,
            r=RISK_FREE_RATE,
        )
        edge_ask = model_prob - float(event.best_ask_price)
        abs_edge = abs(edge_ask)

        rows.append(
            (
                now_utc.replace(tzinfo=None),
                event.market,
                event.gamma_market_id,
                int(event.event_ts_ms),
                event.trade_hash,
                event.symbol,
                event.timeframe,
                float(current_price),
                float(strike),
                float(t_years),
                float(sigma),
                float(model_prob),
                float(edge_ask),
                float(abs_edge),
                float(event.best_bid_price),
                float(event.best_ask_price),
            )
        )
    return rows


async def run_loop() -> None:
    print("[MISPRICING] connecting clickhouse...")
    client = clickhouse_connect.get_client(
        host=CH_HOST,
        port=CH_PORT,
        username=CH_USER,
        password=CH_PASS,
        database=CH_DB,
        secure=False,
        apply_server_timezone=False,
    )
    print("[MISPRICING] clickhouse connected")

    ensure_events_output_table(client)
    ensure_source_table(client)
    print(f"[MISPRICING] output table ready: {CH_DB}.{MISPRICING_EVENTS_TABLE}")
    print(f"[MISPRICING] source table: {CH_DB}.{MISPRICING_SOURCE_TABLE}")

    sigma_state = RollingSigma(SIGMA_WINDOW)
    inferred_strikes: Dict[str, float] = {}

    seen_event_keys: Deque[str] = deque()
    seen_event_key_set: Set[str] = set()
    dedup_window = max(1000, MISPRICING_EVENT_BATCH * 20)

    bootstrap_sec = max(3600, MISPRICING_BOOTSTRAP_SEC)
    last_poll_ingest_time = datetime.now(timezone.utc).replace(tzinfo=None) - timedelta(seconds=bootstrap_sec)
    last_empty_log_at = 0.0
    idle_no_event_ticks = 0

    print(
        f"[MISPRICING] start cursor ingest_time={last_poll_ingest_time} "
        f"(bootstrap_sec={bootstrap_sec})"
    )

    try:
        while True:
            loop = asyncio.get_running_loop()
            started = loop.time()
            now_utc = datetime.now(timezone.utc)
            try:
                events = fetch_recent_up_trade_events(
                    client,
                    last_poll_ingest_time,
                    MISPRICING_EVENT_BATCH,
                )

                if not events:
                    idle_no_event_ticks += 1
                    if idle_no_event_ticks % 5 == 0:
                        # If source feed goes quiet, widen lookback to recover after lags/restarts.
                        last_poll_ingest_time = now_utc.replace(tzinfo=None) - timedelta(seconds=bootstrap_sec)
                else:
                    idle_no_event_ticks = 0

                unique_events: List[UpTradeEvent] = []
                dup_count = 0
                for event in events:
                    key = f"{event.market}|{event.event_ts_ms}|{event.trade_hash}|{event.best_ask_price:.8f}"
                    if key in seen_event_key_set:
                        dup_count += 1
                        continue
                    unique_events.append(event)

                rows = build_event_rows_for_insert(
                    unique_events,
                    sigma_state,
                    now_utc,
                    inferred_strikes,
                )

                if rows:
                    insert_mispricing_event_rows(client, rows)

                    for row in rows:
                        key = f"{row[1]}|{row[3]}|{row[4]}|{row[15]:.8f}"
                        if key in seen_event_key_set:
                            continue
                        seen_event_keys.append(key)
                        seen_event_key_set.add(key)

                    while len(seen_event_keys) > dedup_window:
                        oldest = seen_event_keys.popleft()
                        seen_event_key_set.discard(oldest)

                    latest_ingest = max(x.ingest_time for x in events)
                    last_poll_ingest_time = latest_ingest - timedelta(seconds=1)

                    top = max(rows, key=lambda x: x[13])
                    print(
                        f"[MISPRICING] rows={len(rows)} events={len(unique_events)} dup={dup_count} "
                        f"top_market={top[1]} ask={top[15]:.6f} model={top[11]:.6f} "
                        f"edge_ask={top[12]:.6f} abs_edge={top[13]:.6f}"
                    )
                    last_empty_log_at = started
                else:
                    if events:
                        latest_ingest = max(x.ingest_time for x in events)
                        # Keep overlap so events can be retried while sigma window warms up.
                        last_poll_ingest_time = latest_ingest - timedelta(seconds=120)

                    should_log = (started - last_empty_log_at) >= 5.0
                    if should_log:
                        if events:
                            print(
                                f"[MISPRICING] no rows (events={len(events)}, unique={len(unique_events)}, "
                                "insufficient sigma/current price)"
                            )
                        else:
                            print("[MISPRICING] waiting for new rows in source table")
                        last_empty_log_at = started

            except Exception as e:
                print("[MISPRICING] error:", repr(e))

            elapsed = loop.time() - started
            await asyncio.sleep(max(0.0, MISPRICING_EVERY_SEC - elapsed))

    finally:
        with suppress(Exception):
            client.close()


if __name__ == "__main__":
    asyncio.run(run_loop())
