"""ws_ingest.py

Polymarket Market WS -> ClickHouse ingest (two-table mode).

Goal:
- Store initial UP orderbook snapshot once per market event in table `orderbook`.
- Store UP price changes as deltas in table `pricechange`.

No analytics/modeling in this script.
"""

from __future__ import annotations

import asyncio
import json
import os
import re
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, List, Optional, Set, Tuple, Union
from urllib.parse import urlencode, quote

import certifi
import urllib3
import websockets
from dotenv import load_dotenv


# -------------------- Env --------------------
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, "password.env"), override=True)
load_dotenv(os.path.join(BASE_DIR, ".env"), override=True)

WS_URL = os.getenv("POLY_WS_URL", "wss://ws-subscriptions-clob.polymarket.com/ws/market")
ORIGIN = os.getenv("POLY_WS_ORIGIN", "https://polymarket.com")

POLY_TAG_ID = os.getenv("POLY_TAG_ID", "21")
POLY_ACTIVE = os.getenv("POLY_ACTIVE", "true").lower() in ("1", "true", "yes")
POLY_CLOSED = os.getenv("POLY_CLOSED", "false").lower() in ("1", "true", "yes")
POLY_LIMIT = int(os.getenv("POLY_LIMIT", "200"))
POLY_REFRESH_SEC = int(os.getenv("POLY_REFRESH_SEC", "60"))

POLY_SYMBOLS = [s.strip().upper() for s in os.getenv("POLY_SYMBOLS", "").split(",") if s.strip()]
POLY_TIMEFRAMES = [t.strip().lower() for t in os.getenv("POLY_TIMEFRAMES", "").split(",") if t.strip()]
POLY_MARKET_WHITELIST_IDS = {
    x.strip().lower()
    for x in os.getenv("POLY_MARKET_WHITELIST_IDS", "").split(",")
    if x.strip()
}
POLY_MARKET_EXCLUDE_REGEX = os.getenv("POLY_MARKET_EXCLUDE_REGEX", "").strip()
POLY_REQUIRE_BINARY = os.getenv("POLY_REQUIRE_BINARY", "true").lower() in ("1", "true", "yes")
POLY_REQUIRE_UP_DOWN = os.getenv("POLY_REQUIRE_UP_DOWN", "true").lower() in ("1", "true", "yes")
POLY_TRACK_CURRENT_ONLY = os.getenv("POLY_TRACK_CURRENT_ONLY", "true").lower() in ("1", "true", "yes")
POLY_MAX_MATCHED_MARKETS = int(os.getenv("POLY_MAX_MATCHED_MARKETS", "1"))

CH_HOST = os.getenv("CLICKHOUSE_HOST", "89.169.153.71")
CH_PORT = int(os.getenv("CLICKHOUSE_PORT", "8123"))
CH_USER = os.getenv("CLICKHOUSE_USER", "remote_ingest")
CH_PASS = os.getenv("CLICKHOUSE_PASSWORD", "")
CH_DB = os.getenv("CLICKHOUSE_DB", "polyk")
CH_HTTP_INTERFACE = os.getenv("CLICKHOUSE_HTTP_INTERFACE", "http")
CH_HTTP_HOST = os.getenv("CLICKHOUSE_HTTP_HOST", CH_HOST)
CH_HTTP_PORT = int(os.getenv("CLICKHOUSE_HTTP_PORT", str(CH_PORT)))

ORDERBOOK_TABLE = os.getenv("ORDERBOOK_TABLE", "orderbook")
PRICECHANGE_TABLE = os.getenv("PRICECHANGE_TABLE", "pricechange")
ORDERBOOK_GRID_MIN = float(os.getenv("ORDERBOOK_GRID_MIN", "0.001"))
ORDERBOOK_GRID_MAX = float(os.getenv("ORDERBOOK_GRID_MAX", "0.999"))
ORDERBOOK_GRID_STEP = float(os.getenv("ORDERBOOK_GRID_STEP", "0.001"))

FLUSH_EVERY_N = int(os.getenv("FLUSH_EVERY_N", "200"))
FLUSH_EVERY_SEC = float(os.getenv("FLUSH_EVERY_SEC", "2"))
DEBUG_RAW = os.getenv("DEBUG_RAW", "false").lower() in ("1", "true", "yes")

if CH_USER == "remote_ingest" and not CH_PASS:
    raise RuntimeError("CLICKHOUSE_PASSWORD is empty. Set it in password.env or .env")

POLY_INSECURE_SSL = os.getenv("POLY_INSECURE_SSL", "false").lower() in ("1", "true", "yes")
_http = urllib3.PoolManager(
    cert_reqs="CERT_NONE" if POLY_INSECURE_SSL else "CERT_REQUIRED",
    ca_certs=None if POLY_INSECURE_SSL else certifi.where(),
)

if ORDERBOOK_GRID_STEP <= 0:
    raise RuntimeError("ORDERBOOK_GRID_STEP must be > 0")
if ORDERBOOK_GRID_MAX < ORDERBOOK_GRID_MIN:
    raise RuntimeError("ORDERBOOK_GRID_MAX must be >= ORDERBOOK_GRID_MIN")

GRID_TICKS_COUNT = int(round((ORDERBOOK_GRID_MAX - ORDERBOOK_GRID_MIN) / ORDERBOOK_GRID_STEP))
GRID_TICKS: List[int] = list(range(GRID_TICKS_COUNT + 1))


# -------------------- Dynamic state from Gamma --------------------
CURRENT_ASSET_IDS: List[str] = []
OUTCOME_MAP: Dict[str, str] = {}  # asset_id -> UP/DOWN


def now_msk_naive() -> datetime:
    # Keep ingest_time directly in Moscow wall-clock time for easier Jupyter usage.
    return (datetime.now(timezone.utc) + timedelta(hours=3)).replace(tzinfo=None)


def to_int(x: Any, default: int = 0) -> int:
    try:
        if x is None:
            return default
        if isinstance(x, (int, float)):
            return int(x)
        if isinstance(x, str) and x.strip():
            return int(float(x.strip()))
    except Exception:
        pass
    return default


def to_float(x: Any, default: float = 0.0) -> float:
    try:
        if x is None:
            return default
        if isinstance(x, (int, float)):
            return float(x)
        if isinstance(x, str) and x.strip():
            s = x.strip().replace(" ", "")
            # Handle both "20,767.81" and "20767,81"
            if "," in s and "." in s:
                s = s.replace(",", "")
            elif "," in s and "." not in s:
                s = s.replace(",", ".")
            return float(s)
    except Exception:
        pass
    return default


def price_to_tick(price: float) -> Optional[int]:
    if price < ORDERBOOK_GRID_MIN - 1e-12 or price > ORDERBOOK_GRID_MAX + 1e-12:
        return None
    tick = int(round((price - ORDERBOOK_GRID_MIN) / ORDERBOOK_GRID_STEP))
    if tick < 0 or tick > GRID_TICKS_COUNT:
        return None
    return tick


def tick_to_price(tick: int) -> float:
    return round(ORDERBOOK_GRID_MIN + tick * ORDERBOOK_GRID_STEP, 6)


def normalize_messages(raw: Union[Dict[str, Any], List[Any]]) -> List[Dict[str, Any]]:
    if isinstance(raw, dict):
        return [raw]
    if isinstance(raw, list):
        out: List[Dict[str, Any]] = []
        for x in raw:
            if isinstance(x, dict):
                out.append(x)
            elif isinstance(x, list):
                out.extend([y for y in x if isinstance(y, dict)])
        return out
    return []


def outcome_from_asset_id(asset_id: str) -> str:
    return OUTCOME_MAP.get(str(asset_id), "")


def is_up_asset(asset_id: str) -> bool:
    label = str(OUTCOME_MAP.get(str(asset_id), "")).strip().lower()
    if not label:
        return False
    if "up" in label or "higher" in label:
        return True
    return label in ("yes",)


def is_orderbook(msg: Dict[str, Any]) -> bool:
    event_type = str(msg.get("event_type", "")).lower()
    if event_type and event_type != "book":
        return False
    has_core = all(k in msg for k in ("asset_id", "market", "timestamp"))
    if not has_core:
        return False
    return ("bids" in msg and "asks" in msg) or ("buys" in msg and "sells" in msg)


def is_price_change(msg: Dict[str, Any]) -> bool:
    event_type = str(msg.get("event_type", "")).lower()
    if event_type and event_type != "price_change":
        return False
    return (
        "market" in msg
        and "timestamp" in msg
        and "price_changes" in msg
    )


def extract_book_level_sizes(msg: Dict[str, Any]) -> Tuple[Dict[int, float], Dict[int, float]]:
    """Extract bid/ask size maps from a book event, aggregated by grid tick."""
    bids = msg.get("bids") if "bids" in msg else msg.get("buys", [])
    asks = msg.get("asks") if "asks" in msg else msg.get("sells", [])
    if isinstance(bids, str):
        try:
            bids = json.loads(bids)
        except Exception:
            bids = []
    if isinstance(asks, str):
        try:
            asks = json.loads(asks)
        except Exception:
            asks = []

    bid_sizes_by_tick: Dict[int, float] = {}
    ask_sizes_by_tick: Dict[int, float] = {}
    if isinstance(bids, list):
        for lvl in bids:
            if not isinstance(lvl, dict):
                continue
            p = to_float(lvl.get("price"))
            s = to_float(lvl.get("size"))
            tick = price_to_tick(p)
            if tick is None:
                continue
            if s <= 0:
                continue
            bid_sizes_by_tick[tick] = bid_sizes_by_tick.get(tick, 0.0) + s

    if isinstance(asks, list):
        for lvl in asks:
            if not isinstance(lvl, dict):
                continue
            p = to_float(lvl.get("price"))
            s = to_float(lvl.get("size"))
            tick = price_to_tick(p)
            if tick is None:
                continue
            if s <= 0:
                continue
            ask_sizes_by_tick[tick] = ask_sizes_by_tick.get(tick, 0.0) + s

    return bid_sizes_by_tick, ask_sizes_by_tick


def build_orderbook_rows_from_initial_book(
    msg: Dict[str, Any],
    bid_sizes_by_tick: Dict[int, float],
    ask_sizes_by_tick: Dict[int, float],
) -> List[Tuple]:
    """Build base snapshot rows from first non-empty full book for UP only.

    Output is a dense grid with ORDERBOOK_GRID_STEP.
    Any missing level gets size=0 and inferred side.
    """
    ingest_time = now_msk_naive()
    market = str(msg.get("market", ""))
    asset_id = str(msg.get("asset_id", ""))
    event_ts_ms = to_int(msg.get("timestamp"))
    event_hash = str(msg.get("hash", ""))

    if not is_up_asset(asset_id):
        return []

    if (sum(bid_sizes_by_tick.values()) + sum(ask_sizes_by_tick.values())) <= 0:
        # Ignore empty/partial bootstrap books to avoid all-zero snapshots.
        return []

    best_bid_tick = max(bid_sizes_by_tick.keys()) if bid_sizes_by_tick else None
    best_ask_tick = min(ask_sizes_by_tick.keys()) if ask_sizes_by_tick else None
    if best_bid_tick is not None and best_ask_tick is not None:
        pivot_tick = (best_bid_tick + best_ask_tick) // 2
    elif best_bid_tick is not None:
        pivot_tick = best_bid_tick
    elif best_ask_tick is not None:
        pivot_tick = best_ask_tick
    else:
        pivot_tick = GRID_TICKS_COUNT // 2

    out: List[Tuple] = []
    for tick in GRID_TICKS:
        price = tick_to_price(tick)
        if tick in bid_sizes_by_tick:
            side = "bid"
            size = bid_sizes_by_tick[tick]
        elif tick in ask_sizes_by_tick:
            side = "ask"
            size = ask_sizes_by_tick[tick]
        else:
            side = "bid" if tick <= pivot_tick else "ask"
            size = 0.0

        out.append(
            (
                ingest_time,
                market,
                asset_id,
                event_ts_ms,
                event_hash,
                side,
                price,
                float(size),
            )
        )

    return out


def build_pricechange_rows(
    msg: Dict[str, Any],
    level_state: Dict[str, float],
    ready_snapshot_keys: Set[str],
) -> List[Tuple]:
    """Parse WS price_change and store orderbook size deltas by level.

    We use `price_change` as source transport, but persist delta(size) for
    (market, asset_id, side, price_tick), not trade prints.
    """
    ingest_time = now_msk_naive()
    market = str(msg.get("market", ""))
    event_ts_ms = to_int(msg.get("timestamp"))
    pcs = msg.get("price_changes") or []
    if isinstance(pcs, str):
        try:
            pcs = json.loads(pcs)
        except Exception:
            pcs = []
    if not isinstance(pcs, list):
        return []

    out: List[Tuple] = []
    for pc in pcs:
        if not isinstance(pc, dict):
            continue

        asset_id = str(pc.get("asset_id", ""))
        if not is_up_asset(asset_id):
            continue
        snapshot_key = f"{market}|{asset_id}"
        if snapshot_key not in ready_snapshot_keys:
            # Wait for first book snapshot for this market/asset baseline.
            continue

        side_raw = str(pc.get("side", "")).strip().lower()
        if side_raw == "buy":
            side = "bid"
        elif side_raw == "sell":
            side = "ask"
        elif side_raw in ("bid", "ask"):
            side = side_raw
        else:
            continue

        tick = price_to_tick(to_float(pc.get("price")))
        if tick is None:
            continue

        new_size = to_float(pc.get("size"))
        price = tick_to_price(tick)
        event_hash = str(pc.get("hash", "") or msg.get("hash", ""))
        state_key = f"{market}|{asset_id}|{side}|{tick}"
        prev_size = level_state.get(state_key, 0.0)
        delta_size = new_size - prev_size
        if abs(delta_size) <= 1e-12:
            continue

        if abs(new_size) <= 1e-12:
            level_state.pop(state_key, None)
        else:
            level_state[state_key] = new_size

        out.append(
            (
                ingest_time,
                market,
                asset_id,
                event_ts_ms,
                event_hash,
                side,
                price,
                float(delta_size),
            )
        )

    return out


# -------------------- Gamma discovery --------------------
def build_gamma_markets_url(offset: int = 0) -> str:
    base = "https://gamma-api.polymarket.com/markets"
    params = {"tag_id": POLY_TAG_ID, "limit": POLY_LIMIT, "offset": offset}
    if POLY_ACTIVE:
        params["active"] = "true"
    if not POLY_CLOSED:
        params["closed"] = "false"
    return f"{base}?{urlencode(params)}"


def http_get_json(url: str) -> Any:
    resp = _http.request(
        "GET",
        url,
        headers={"Accept": "application/json", "User-Agent": "Mozilla/5.0"},
        timeout=30.0,
        retries=False,
    )
    if resp.status >= 300:
        raise RuntimeError(f"HTTP GET failed {resp.status}: {resp.data.decode('utf-8', errors='replace')}")
    return json.loads(resp.data.decode("utf-8"))


def _gamma_payload_to_markets(payload: Any) -> List[Dict[str, Any]]:
    if isinstance(payload, list):
        return [m for m in payload if isinstance(m, dict)]
    if isinstance(payload, dict):
        for k in ("data", "markets", "results"):
            v = payload.get(k)
            if isinstance(v, list):
                return [m for m in v if isinstance(m, dict)]
    return []


def _extract_market_id(m: Dict[str, Any]) -> str:
    for k in ("conditionId", "condition_id", "market", "id"):
        v = m.get(k)
        if isinstance(v, str) and v:
            return v
    return ""


def _extract_clob_token_ids(m: Dict[str, Any]) -> List[str]:
    for k in ("clobTokenIds", "clob_token_ids", "clobTokenIDs"):
        v = m.get(k)
        if isinstance(v, list):
            return [str(x) for x in v if str(x)]
        if isinstance(v, str):
            try:
                arr = json.loads(v)
                if isinstance(arr, list):
                    return [str(x) for x in arr if str(x)]
            except Exception:
                return []
    return []


def _extract_outcomes(m: Dict[str, Any]) -> List[str]:
    v = m.get("outcomes")
    if isinstance(v, list):
        return [str(x) for x in v]
    return []


def _normalize_outcome_label(label: str) -> str:
    s = re.sub(r"[^A-Z0-9]+", "", str(label).upper())
    if s in ("UP", "HIGHER"):
        return "UP"
    if s in ("DOWN", "LOWER"):
        return "DOWN"
    if s in ("YES",):
        return "YES"
    if s in ("NO",):
        return "NO"
    return s


def _market_text_bundle(m: Dict[str, Any]) -> Tuple[str, str]:
    qtn = str(m.get("question") or "")
    ttl = str(m.get("title") or "")
    nm = str(m.get("name") or "")
    slug = str(m.get("slug") or "")
    text = f"{qtn} {ttl} {nm} {slug}"
    return text.upper(), text.lower()


def _parse_gamma_datetime_to_ts(value: Any) -> Optional[float]:
    if value is None:
        return None
    if isinstance(value, (int, float)):
        # Gamma may return ms or sec depending on endpoint/field.
        v = float(value)
        if v > 1e12:
            return v / 1000.0
        if v > 1e9:
            return v
        return None
    if not isinstance(value, str):
        return None
    s = value.strip()
    if not s:
        return None
    # ISO8601 compatibility for Python fromisoformat
    if s.endswith("Z"):
        s = s[:-1] + "+00:00"
    try:
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.timestamp()
    except Exception:
        return None


def _market_end_ts(m: Dict[str, Any]) -> Optional[float]:
    for k in ("endDate", "end_date", "endTime", "end_time", "closedTime", "closed_time"):
        ts = _parse_gamma_datetime_to_ts(m.get(k))
        if ts is not None:
            return ts
    return None


def _market_debug_label(m: Dict[str, Any]) -> str:
    mid = _extract_market_id(m) or str(m.get("id") or "")
    slug = str(m.get("slug") or "")
    end_ts = _market_end_ts(m)
    end_s = "?"
    if end_ts is not None:
        end_s = datetime.fromtimestamp(end_ts, tz=timezone.utc).isoformat()
    return f"id={mid} slug={slug} end_utc={end_s}"


def _market_sort_key_for_current(m: Dict[str, Any], now_ts: float) -> Tuple[int, float, str]:
    end_ts = _market_end_ts(m)
    if end_ts is None:
        # Unknown end -> send to the back
        return (2, float("inf"), str(m.get("slug") or m.get("id") or ""))
    # Prefer markets that are not yet expired, then nearest end time.
    if end_ts >= now_ts:
        return (0, end_ts, str(m.get("slug") or m.get("id") or ""))
    return (1, end_ts, str(m.get("slug") or m.get("id") or ""))


def _has_up_down_intent(m: Dict[str, Any], text_l: str) -> bool:
    slug = str(m.get("slug") or "").lower()
    if "up-or-down" in slug:
        return True
    if re.search(r"\bup\s+or\s+down\b", text_l):
        return True

    normalized = {_normalize_outcome_label(x) for x in _extract_outcomes(m)}
    return "UP" in normalized and "DOWN" in normalized


def _is_binary_market(m: Dict[str, Any]) -> bool:
    return len(_extract_clob_token_ids(m)) == 2


def _market_id_keys(m: Dict[str, Any]) -> Set[str]:
    out: Set[str] = set()
    condition_id = str(m.get("conditionId", "")).strip().lower()
    market_id = str(m.get("id", "")).strip().lower()
    if condition_id:
        out.add(condition_id)
    if market_id:
        out.add(market_id)
    return out


def _symbol_match(title: str, sym: str) -> bool:
    sym = re.escape(sym.upper())
    return re.search(rf"(^|[^A-Z0-9])\$?{sym}([^A-Z0-9]|$)", title) is not None


def _timeframe_match(title: str, tf: str) -> bool:
    tf = tf.lower().strip()
    patterns = {
        "15m": r"\b15\s*[- ]?\s*(MIN|MINS|MINUTE|MINUTES)\b",
        "30m": r"\b30\s*[- ]?\s*(MIN|MINS|MINUTE|MINUTES)\b",
        "1h": r"\b(1\s*[- ]?\s*(H|HR|HOUR|HOURS)|60\s*[- ]?\s*(MIN|MINS|MINUTE|MINUTES))\b",
        "4h": r"\b4\s*[- ]?\s*(H|HR|HOUR|HOURS)\b",
    }
    pat = patterns.get(tf)
    if not pat:
        m = re.match(r"^(\d+)(m|h)$", tf)
        if not m:
            return False
        n, unit = m.group(1), m.group(2)
        if unit == "m":
            pat = rf"\b{re.escape(n)}\s*[- ]?\s*(MIN|MINS|MINUTE|MINUTES)\b"
        else:
            pat = rf"\b{re.escape(n)}\s*[- ]?\s*(H|HR|HOUR|HOURS)\b"
    return re.search(pat, title, flags=re.IGNORECASE) is not None


def market_passes_filters(m: Dict[str, Any]) -> bool:
    title_blob, text_l = _market_text_bundle(m)
    slug_l = str(m.get("slug") or "").lower()

    if POLY_MARKET_WHITELIST_IDS:
        if not (_market_id_keys(m) & POLY_MARKET_WHITELIST_IDS):
            return False

    if POLY_MARKET_EXCLUDE_REGEX:
        try:
            if re.search(POLY_MARKET_EXCLUDE_REGEX, text_l, flags=re.IGNORECASE):
                return False
        except re.error:
            # Ignore invalid regex to avoid breaking ingest loop.
            pass

    if POLY_REQUIRE_BINARY and not _is_binary_market(m):
        return False

    if POLY_REQUIRE_UP_DOWN and not _has_up_down_intent(m, text_l):
        return False

    if POLY_SYMBOLS and not any(_symbol_match(title_blob, s) for s in POLY_SYMBOLS):
        return False

    if POLY_TIMEFRAMES:
        if any(tf in slug_l for tf in POLY_TIMEFRAMES):
            return True
        text_for_tf = text_l
        if not any(_timeframe_match(text_for_tf, tf) for tf in POLY_TIMEFRAMES):
            return False

    return True


def fetch_filtered_markets() -> List[Dict[str, Any]]:
    all_markets: List[Dict[str, Any]] = []
    offset = 0
    while True:
        payload = http_get_json(build_gamma_markets_url(offset))
        page = _gamma_payload_to_markets(payload)
        if not page:
            break
        all_markets.extend(page)
        if len(page) < POLY_LIMIT:
            break
        offset += POLY_LIMIT
    matched = [m for m in all_markets if market_passes_filters(m)]

    # If a strict whitelist is set, keep all matched whitelist markets as-is.
    if POLY_MARKET_WHITELIST_IDS:
        return matched

    # Default behavior for this project: track only the currently relevant market
    # (nearest upcoming end time) so ingest rolls from one bucket to the next.
    if matched and POLY_TRACK_CURRENT_ONLY and POLY_MAX_MATCHED_MARKETS != 0:
        now_ts = datetime.now(timezone.utc).timestamp()
        matched = sorted(matched, key=lambda m: _market_sort_key_for_current(m, now_ts))
        limit = max(1, POLY_MAX_MATCHED_MARKETS)
        matched = matched[:limit]

    return matched


def build_outcome_map(markets: List[Dict[str, Any]]) -> Tuple[List[str], Dict[str, str]]:
    asset_ids: List[str] = []
    outcome_map: Dict[str, str] = {}
    seen_assets: Set[str] = set()

    for m in markets:
        market_id = _extract_market_id(m)
        toks = _extract_clob_token_ids(m)
        if not market_id or not toks:
            continue

        outcomes = _extract_outcomes(m)
        if outcomes and len(outcomes) >= len(toks):
            labels = outcomes[: len(toks)]
        else:
            labels = ["UP", "DOWN"] if len(toks) == 2 else [f"OUTCOME_{i+1}" for i in range(len(toks))]

        for aid, label in zip(toks, labels):
            if aid not in seen_assets:
                seen_assets.add(aid)
                asset_ids.append(aid)
            outcome_map[aid] = str(label)

    if not asset_ids:
        raise RuntimeError("No markets with clobTokenIds found for selected filters")

    return asset_ids, outcome_map


async def refresh_markets_loop(reload_event: asyncio.Event) -> None:
    global CURRENT_ASSET_IDS, OUTCOME_MAP
    last_sig: Optional[str] = None

    while True:
        load_dotenv(os.path.join(BASE_DIR, "password.env"), override=True)
        load_dotenv(os.path.join(BASE_DIR, ".env"), override=True)

        try:
            markets = fetch_filtered_markets()
            if not markets:
                print("[REFRESH] no markets matched filters")
                await asyncio.sleep(max(10, POLY_REFRESH_SEC))
                continue

            asset_ids, outcome_map = build_outcome_map(markets)
            sig = json.dumps({"assets": sorted(set(asset_ids))}, sort_keys=True)

            if sig != last_sig:
                CURRENT_ASSET_IDS = asset_ids
                OUTCOME_MAP = outcome_map
                print(f"[REFRESH] markets={len(markets)} assets={len(asset_ids)}")
                if markets:
                    print(f"[REFRESH] selected { _market_debug_label(markets[0]) }")
                reload_event.set()
                last_sig = sig

        except Exception as e:
            print("[REFRESH] error:", repr(e))

        await asyncio.sleep(max(10, POLY_REFRESH_SEC))


# -------------------- ClickHouse I/O --------------------
def ch_http_command(sql: str) -> None:
    params = {
        "database": CH_DB,
        "query": sql,
        "user": CH_USER,
        "password": CH_PASS,
    }
    url = f"{CH_HTTP_INTERFACE}://{CH_HTTP_HOST}:{CH_HTTP_PORT}/?" + urlencode(params, quote_via=quote)
    resp = _http.request(
        "POST",
        url,
        body=b"",
        headers={"Content-Type": "text/plain"},
        timeout=30.0,
        retries=False,
    )
    if resp.status >= 300:
        raise RuntimeError(f"HTTP COMMAND failed {resp.status}: {resp.data.decode('utf-8', errors='replace')}")


def ch_http_insert_json_each_row(table: str, columns: List[str], rows: List[Tuple]) -> None:
    if not rows:
        return

    dict_rows: List[Dict[str, Any]] = []
    for r in rows:
        d = {columns[i]: r[i] for i in range(len(columns))}
        if isinstance(d.get("ingest_time"), datetime):
            d["ingest_time"] = d["ingest_time"].strftime("%Y-%m-%d %H:%M:%S")
        dict_rows.append(d)

    body = "\n".join(json.dumps(d, ensure_ascii=False, separators=(",", ":")) for d in dict_rows) + "\n"
    insert_sql = f"INSERT INTO {table} ({', '.join(columns)}) FORMAT JSONEachRow"

    params = {
        "database": CH_DB,
        "query": insert_sql,
        "user": CH_USER,
        "password": CH_PASS,
    }
    url = f"{CH_HTTP_INTERFACE}://{CH_HTTP_HOST}:{CH_HTTP_PORT}/?" + urlencode(params, quote_via=quote)
    resp = _http.request(
        "POST",
        url,
        body=body.encode("utf-8"),
        headers={"Content-Type": "application/json"},
        timeout=30.0,
        retries=False,
    )
    if resp.status >= 300:
        raise RuntimeError(f"HTTP INSERT failed {resp.status}: {resp.data.decode('utf-8', errors='replace')}")


def ensure_tables() -> None:
    # ClickHouse 18.x on this server has limited timezone DB support.
    # For stable MSK display we materialize as UTC+3 seconds shift.
    msk_expr = "toDateTime(intDiv(event_ts_ms, 1000) + 10800)"
    q_orderbook = f"""
CREATE TABLE IF NOT EXISTS {CH_DB}.{ORDERBOOK_TABLE}
(
  ingest_time DateTime,
  market String,
  asset_id String,
  event_ts_ms UInt64,
  event_time_msk DateTime MATERIALIZED {msk_expr},
  hash String,
  side String,
  price Float64,
  size Float64
)
ENGINE = MergeTree
ORDER BY (market, asset_id, event_ts_ms, side, price, hash)
"""
    q_pricechange = f"""
CREATE TABLE IF NOT EXISTS {CH_DB}.{PRICECHANGE_TABLE}
(
  ingest_time DateTime,
  market String,
  asset_id String,
  event_ts_ms UInt64,
  event_time_msk DateTime MATERIALIZED {msk_expr},
  hash String,
  side String,
  price Float64,
  size Float64
)
ENGINE = MergeTree
ORDER BY (market, asset_id, event_ts_ms, hash, side, price)
"""
    ch_http_command(q_orderbook)
    ch_http_command(q_pricechange)
    # Drop legacy columns if table existed from previous version.
    try:
        ch_http_command(f"ALTER TABLE {CH_DB}.{PRICECHANGE_TABLE} DROP COLUMN best_bid")
    except Exception:
        pass
    try:
        ch_http_command(f"ALTER TABLE {CH_DB}.{PRICECHANGE_TABLE} DROP COLUMN best_ask")
    except Exception:
        pass
    # Recreate materialized event_time_msk with stable UTC+3 conversion.
    try:
        ch_http_command(f"ALTER TABLE {CH_DB}.{ORDERBOOK_TABLE} DROP COLUMN event_time_msk")
    except Exception:
        pass
    try:
        ch_http_command(
            f"ALTER TABLE {CH_DB}.{ORDERBOOK_TABLE} "
            f"ADD COLUMN event_time_msk DateTime MATERIALIZED {msk_expr}"
        )
    except Exception:
        pass
    try:
        ch_http_command(f"ALTER TABLE {CH_DB}.{PRICECHANGE_TABLE} DROP COLUMN event_time_msk")
    except Exception:
        pass
    try:
        ch_http_command(
            f"ALTER TABLE {CH_DB}.{PRICECHANGE_TABLE} "
            f"ADD COLUMN event_time_msk DateTime MATERIALIZED {msk_expr}"
        )
    except Exception:
        pass


# -------------------- WS --------------------
async def ws_subscribe(ws) -> None:
    await ws.send(json.dumps({"assets_ids": CURRENT_ASSET_IDS, "type": "market"}))


async def flusher_loop(
    orderbook_buf: List[Tuple],
    pricechange_buf: List[Tuple],
    lock: asyncio.Lock,
    flush_event: asyncio.Event,
) -> None:
    while True:
        try:
            await asyncio.wait_for(flush_event.wait(), timeout=FLUSH_EVERY_SEC)
        except asyncio.TimeoutError:
            pass

        async with lock:
            if not orderbook_buf and not pricechange_buf:
                flush_event.clear()
                continue

            ob = orderbook_buf[:]
            pc = pricechange_buf[:]
            orderbook_buf.clear()
            pricechange_buf.clear()
            flush_event.clear()

        failed_ob: List[Tuple] = []
        failed_pc: List[Tuple] = []

        if ob:
            try:
                cols = ["ingest_time", "market", "asset_id", "event_ts_ms", "hash", "side", "price", "size"]
                ch_http_insert_json_each_row(f"{CH_DB}.{ORDERBOOK_TABLE}", cols, ob)
                print(f"CH inserted {ORDERBOOK_TABLE}: {len(ob)} rows")
            except Exception as e:
                failed_ob = ob
                print(f"CH INSERT ERROR {ORDERBOOK_TABLE}:", repr(e))

        if pc:
            try:
                cols = [
                    "ingest_time",
                    "market",
                    "asset_id",
                    "event_ts_ms",
                    "hash",
                    "side",
                    "price",
                    "size",
                ]
                ch_http_insert_json_each_row(f"{CH_DB}.{PRICECHANGE_TABLE}", cols, pc)
                print(f"CH inserted {PRICECHANGE_TABLE}: {len(pc)} rows")
            except Exception as e:
                failed_pc = pc
                print(f"CH INSERT ERROR {PRICECHANGE_TABLE}:", repr(e))

        if failed_ob or failed_pc:
            async with lock:
                if failed_ob:
                    orderbook_buf[:0] = failed_ob
                if failed_pc:
                    pricechange_buf[:0] = failed_pc


async def ingest_forever() -> None:
    orderbook_buf: List[Tuple] = []
    pricechange_buf: List[Tuple] = []

    lock = asyncio.Lock()
    flush_event = asyncio.Event()
    reload_event = asyncio.Event()

    # First full book snapshot saved once per (market, asset_id)
    initial_snapshot_written: Set[str] = set()
    # Last known absolute size per (market, asset_id, side, price_tick),
    # used to convert price_change stream into delta(size).
    pricechange_level_state: Dict[str, float] = {}

    asyncio.create_task(refresh_markets_loop(reload_event))
    asyncio.create_task(flusher_loop(orderbook_buf, pricechange_buf, lock, flush_event))

    # Initial discovery before first subscribe
    markets = fetch_filtered_markets()
    asset_ids, outcome_map = build_outcome_map(markets)
    global CURRENT_ASSET_IDS, OUTCOME_MAP
    CURRENT_ASSET_IDS = asset_ids
    OUTCOME_MAP = outcome_map

    ensure_tables()
    print(f"[INIT] orderbook table ready: {CH_DB}.{ORDERBOOK_TABLE}")
    print(f"[INIT] pricechange table ready: {CH_DB}.{PRICECHANGE_TABLE}")
    print(
        f"[INIT] orderbook grid min={ORDERBOOK_GRID_MIN} max={ORDERBOOK_GRID_MAX} "
        f"step={ORDERBOOK_GRID_STEP} levels={len(GRID_TICKS)}"
    )
    print(f"[INIT] markets={len(markets)} assets={len(asset_ids)}")
    if markets:
        print(f"[INIT] selected { _market_debug_label(markets[0]) }")

    backoff = 1.0
    while True:
        try:
            async with websockets.connect(
                WS_URL,
                ping_interval=20,
                ping_timeout=20,
                close_timeout=5,
                open_timeout=15,
                max_size=10 * 1024 * 1024,
                origin=ORIGIN,
            ) as ws:
                print("WS connected")
                await ws_subscribe(ws)
                print("WS subscribed")
                reload_event.clear()

                async for message in ws:
                    if reload_event.is_set():
                        print("[WS] reload requested; reconnecting...")
                        break

                    if DEBUG_RAW:
                        print("RAW:", message[:400])

                    try:
                        raw = json.loads(message)
                    except Exception:
                        continue

                    for msg in normalize_messages(raw):
                        if is_orderbook(msg):
                            market = str(msg.get("market", ""))
                            asset_id = str(msg.get("asset_id", ""))
                            if not is_up_asset(asset_id):
                                continue

                            snapshot_key = f"{market}|{asset_id}"
                            if snapshot_key in initial_snapshot_written:
                                continue

                            bid_sizes_by_tick, ask_sizes_by_tick = extract_book_level_sizes(msg)
                            rows = build_orderbook_rows_from_initial_book(msg, bid_sizes_by_tick, ask_sizes_by_tick)
                            if rows:
                                initial_snapshot_written.add(snapshot_key)
                                # Seed pricechange state with absolute sizes from initial book,
                                # so subsequent deltas are relative to this baseline.
                                for tick, sz in bid_sizes_by_tick.items():
                                    if abs(sz) > 1e-12:
                                        key = f"{market}|{asset_id}|bid|{tick}"
                                        pricechange_level_state[key] = float(sz)
                                for tick, sz in ask_sizes_by_tick.items():
                                    if abs(sz) > 1e-12:
                                        key = f"{market}|{asset_id}|ask|{tick}"
                                        pricechange_level_state[key] = float(sz)
                                async with lock:
                                    orderbook_buf.extend(rows)
                                    if (len(orderbook_buf) + len(pricechange_buf)) >= FLUSH_EVERY_N:
                                        flush_event.set()

                        elif is_price_change(msg):
                            rows = build_pricechange_rows(msg, pricechange_level_state, initial_snapshot_written)
                            if rows:
                                async with lock:
                                    pricechange_buf.extend(rows)
                                    if (len(orderbook_buf) + len(pricechange_buf)) >= FLUSH_EVERY_N:
                                        flush_event.set()

                backoff = 1.0

        except Exception as e:
            print("WS error:", repr(e))
            await asyncio.sleep(backoff)
            backoff = min(backoff * 2, 30.0)


if __name__ == "__main__":
    asyncio.run(ingest_forever())