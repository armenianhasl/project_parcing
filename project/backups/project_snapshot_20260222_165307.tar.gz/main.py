from __future__ import annotations

import asyncio
import json
import os
from typing import Any, Dict, List, Union

import websockets
from dotenv import load_dotenv

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
load_dotenv(os.path.join(BASE_DIR, "password.env"), override=True)
load_dotenv(os.path.join(BASE_DIR, ".env"), override=True)

WS_URL = os.getenv("POLY_WS_URL", "wss://ws-subscriptions-clob.polymarket.com/ws/market")
ORIGIN = os.getenv("POLY_WS_ORIGIN", "https://polymarket.com")


def parse_asset_ids() -> List[str]:
    raw = os.getenv("POLY_ASSET_IDS", "").strip()
    if raw:
        return [x.strip() for x in raw.split(",") if x.strip()]

    try:
        from poly_markets import ASSET_IDS as STATIC_ASSET_IDS
        return [str(x) for x in STATIC_ASSET_IDS if str(x)]
    except Exception:
        return []


def normalize_messages(raw: Union[Dict[str, Any], List[Any]]) -> List[Dict[str, Any]]:
    if isinstance(raw, dict):
        return [raw]
    if isinstance(raw, list):
        out: List[Dict[str, Any]] = []
        for item in raw:
            if isinstance(item, dict):
                out.append(item)
            elif isinstance(item, list):
                out.extend([x for x in item if isinstance(x, dict)])
        return out
    return []


async def ws_subscribe(ws: websockets.WebSocketClientProtocol, asset_ids: List[str]) -> None:
    await ws.send(json.dumps({"assets_ids": asset_ids, "type": "market"}))


async def ingest_forever() -> None:
    asset_ids = parse_asset_ids()
    if not asset_ids:
        raise RuntimeError(
            "No asset ids for subscription. Set POLY_ASSET_IDS in .env or keep valid ids in poly_markets.py."
        )

    async with websockets.connect(
        WS_URL,
        ping_interval=20,
        ping_timeout=20,
        close_timeout=5,
        open_timeout=15,
        max_size=10 * 1024 * 1024,
        origin=ORIGIN,
    ) as ws:
        await ws_subscribe(ws, asset_ids)
        print("WS subscribe sent:", {"assets_ids": asset_ids, "type": "market"})

        async for raw in ws:
            try:
                payload = json.loads(raw)
            except Exception:
                continue

            for msg in normalize_messages(payload):
                event_type = str(msg.get("event_type", ""))
                if event_type not in ("book", "price_change"):
                    continue
                print(
                    "event:",
                    {
                        "event_type": event_type,
                        "market": msg.get("market"),
                        "asset_id": msg.get("asset_id"),
                        "timestamp": msg.get("timestamp"),
                    },
                )


if __name__ == "__main__":
    asyncio.run(ingest_forever())
