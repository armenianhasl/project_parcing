# %%
# Jupyter / VSCode notebook helpers for ClickHouse + Polymarket orderbook project
# Copy/paste cells from this file into a notebook, or run with "# %%" cells in VSCode.

import os
import pandas as pd
import clickhouse_connect
from dotenv import load_dotenv

load_dotenv(".env", override=True)

c = clickhouse_connect.get_client(
    host=os.getenv("CLICKHOUSE_HOST"),
    port=int(os.getenv("CLICKHOUSE_PORT", "8123")),
    username=os.getenv("CLICKHOUSE_USER"),
    password=os.getenv("CLICKHOUSE_PASSWORD"),
    database=os.getenv("CLICKHOUSE_DB", "polyk"),
)


def ch_cmd(sql: str):
    """Execute DDL/DML (TRUNCATE/ALTER/etc.)."""
    return c.command(sql)


def ch_df(sql: str) -> pd.DataFrame:
    """Execute SELECT and return a pandas DataFrame."""
    res = c.query(sql)
    return pd.DataFrame(res.result_rows, columns=res.column_names)


pd.set_option("display.max_columns", 50)
pd.set_option("display.width", 200)


# %%
# Terminal commands (run in terminal, not in Jupyter):
# source /Users/roman230901gmail.com/Desktop/project/.venv/bin/activate
# python /Users/roman230901gmail.com/Desktop/project/ws_ingest.py
#
# Stop ingest before TRUNCATE:
# Ctrl+C


# %%
# Clean tables (run only when ws_ingest.py is stopped)
ch_cmd("TRUNCATE TABLE polyk.orderbook")
ch_cmd("TRUNCATE TABLE polyk.pricechange")

ch_df(
    """
SELECT
  (SELECT count() FROM polyk.orderbook) AS ob_rows,
  (SELECT count() FROM polyk.pricechange) AS pc_rows
"""
)


# %%
# Quick health checks
ch_df(
    """
SELECT
  countDistinct(tuple(market, asset_id, hash)) AS snapshots_cnt,
  count() AS total_orderbook_rows,
  count() / 999 AS rows_div_999
FROM polyk.orderbook
"""
)


# %%
# Snapshot list (metadata)
df_snapshots = ch_df(
    """
SELECT
  market,
  asset_id,
  hash,
  min(event_time_msk) AS snapshot_time_msk,
  max(event_ts_ms) AS snapshot_ts_ms,
  count() AS levels,
  sum(if(size > 0, 1, 0)) AS non_zero_levels,
  sum(size) AS total_size
FROM polyk.orderbook
GROUP BY market, asset_id, hash
ORDER BY snapshot_ts_ms DESC
"""
)
df_snapshots


# %%
# Pick a snapshot by row index from df_snapshots (0 = newest)
snapshot_idx = 0
row = df_snapshots.iloc[snapshot_idx]

market = row["market"]
asset_id = row["asset_id"]
ob_hash = row["hash"]

print("market:", market)
print("asset_id:", asset_id)
print("hash:", ob_hash)
print("snapshot_time_msk:", row["snapshot_time_msk"])
print("non_zero_levels:", row["non_zero_levels"])


# %%
# Full selected snapshot (999 rows)
df_orderbook = ch_df(
    f"""
SELECT
    event_time_msk,
    ingest_time,
    market,
    asset_id,
    hash,
    side,
    price,
    size,
    event_ts_ms
FROM polyk.orderbook
WHERE market = '{market}'
  AND asset_id = '{asset_id}'
  AND hash = '{ob_hash}'
ORDER BY price ASC
"""
)
df_orderbook


# %%
# Only non-zero levels in selected snapshot (usually the most useful view)
df_orderbook_nonzero = ch_df(
    f"""
SELECT
    side,
    price,
    size,
    event_time_msk,
    ingest_time,
    event_ts_ms
FROM polyk.orderbook
WHERE market = '{market}'
  AND asset_id = '{asset_id}'
  AND hash = '{ob_hash}'
  AND size > 0
ORDER BY price ASC
"""
)
df_orderbook_nonzero


# %%
# Latest pricechange rows for the same market/asset
# NOTE: pricechange.size is DELTA size at level (not absolute size, not a trade print)
df_pricechange = ch_df(
    f"""
SELECT
    event_time_msk,
    ingest_time,
    market,
    asset_id,
    hash,
    side,
    price,
    size,
    event_ts_ms
FROM polyk.pricechange
WHERE market = '{market}'
  AND asset_id = '{asset_id}'
ORDER BY event_ts_ms DESC, price ASC
LIMIT 500
"""
)
df_pricechange


# %%
# Pricechange summary
ch_df(
    f"""
SELECT
    side,
    count() AS rows_cnt,
    sum(abs(size)) AS abs_delta_sum,
    min(event_time_msk) AS min_time_msk,
    max(event_time_msk) AS max_time_msk
FROM polyk.pricechange
WHERE market = '{market}'
  AND asset_id = '{asset_id}'
GROUP BY side
ORDER BY side
"""
)
